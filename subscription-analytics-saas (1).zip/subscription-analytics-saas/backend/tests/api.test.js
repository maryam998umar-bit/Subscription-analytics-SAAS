// Integration tests: need a migrated + seeded DB (see README). Run: npm test
const { test, before, after } = require("node:test"), assert = require("node:assert");
process.env.JWT_SECRET = process.env.JWT_SECRET || "test-secret";
const app = require("../src/app"), { pool } = require("../src/db");
let srv, base; const tok = {};
const call = (m, p, body, t) => fetch(base + p, { method: m, headers: { "content-type": "application/json", ...(t && { authorization: "Bearer " + t }) }, body: body && JSON.stringify(body) });
before(async () => {
  srv = app.listen(0); base = "http://localhost:" + srv.address().port;
  for (const r of ["admin", "analyst", "viewer"]) tok[r] = (await (await call("POST", "/auth/login", { email: r + "@demo.test", password: "Passw0rd!demo" })).json()).token;
});
after(async () => { srv.close(); await pool.end(); });

test("rejects bad login", async () => assert.equal((await call("POST", "/auth/login", { email: "admin@demo.test", password: "x" })).status, 401));
test("requires token", async () => assert.equal((await call("GET", "/customers")).status, 401));
test("viewer cannot create customer (RBAC)", async () => assert.equal((await call("POST", "/customers", { name: "Zed", email: "z@z.io", plan_id: "starter" }, tok.viewer)).status, 403));
test("validates email", async () => assert.equal((await call("POST", "/customers", { name: "Zed", email: "nope", plan_id: "starter" }, tok.admin)).status, 400));
test("rejects duplicate email", async () => {
  const b = { name: "Dup Co", email: `dup${Date.now()}@x.io`, plan_id: "starter" };
  assert.equal((await call("POST", "/customers", b, tok.admin)).status, 201);
  assert.equal((await call("POST", "/customers", b, tok.admin)).status, 409);
});
test("analyst can record usage, invalid units rejected", async () => {
  assert.equal((await call("POST", "/usage", { customer_id: 1, units: 500 }, tok.analyst)).status, 201);
  assert.equal((await call("POST", "/usage", { customer_id: 1, units: -5 }, tok.analyst)).status, 400);
});
test("analyst cannot run billing", async () => assert.equal((await call("POST", "/billing/run", {}, tok.analyst)).status, 403));
test("billing run with failRate 1 marks customers past_due, retry recovers", async () => {
  const r = await (await call("POST", "/billing/run", { failRate: 1 }, tok.admin)).json();
  assert.ok(r.failed > 0 && r.paid === 0);
  const id = (await (await call("GET", "/customers", null, tok.admin)).json()).find(c => c.status === "past_due").id;
  assert.equal((await call("POST", "/billing/retry/" + id, {}, tok.admin)).status, 200);
});
test("audit log records actions", async () => {
  const a = await (await call("GET", "/audit", null, tok.admin)).json();
  assert.ok(a.some(x => x.action === "billing.run"));
});
test("analytics summary shape", async () => {
  const s = await (await call("GET", "/analytics/summary", null, tok.viewer)).json();
  assert.ok(typeof s.mrr_cents === "number" && Array.isArray(s.by_plan));
});
