CREATE TABLE users (id SERIAL PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','analyst','viewer')));
CREATE TABLE plans (id TEXT PRIMARY KEY, name TEXT NOT NULL, price_cents INT NOT NULL CHECK (price_cents>=0),
  included_units INT NOT NULL, overage_cents_per_1000 INT NOT NULL);
CREATE TABLE customers (id SERIAL PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
  plan_id TEXT NOT NULL REFERENCES plans(id), status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','past_due','canceled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(), canceled_at TIMESTAMPTZ);
CREATE TABLE usage_records (id SERIAL PRIMARY KEY, customer_id INT NOT NULL REFERENCES customers(id),
  units INT NOT NULL CHECK (units>0), billed BOOLEAN NOT NULL DEFAULT false, recorded_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE billing_events (id SERIAL PRIMARY KEY, customer_id INT NOT NULL REFERENCES customers(id),
  type TEXT NOT NULL, amount_cents INT NOT NULL, status TEXT NOT NULL CHECK (status IN ('paid','failed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE audit_log (id SERIAL PRIMARY KEY, user_id INT, role TEXT, action TEXT NOT NULL, entity TEXT, entity_id INT,
  meta JSONB, created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE INDEX ON usage_records (customer_id, billed);
CREATE INDEX ON billing_events (created_at);
INSERT INTO plans VALUES ('starter','Starter',2900,1000,200),('growth','Growth',9900,10000,150),('scale','Scale',29900,100000,100);
