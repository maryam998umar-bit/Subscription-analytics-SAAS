# Work log
| Date | Week | What I did | Decision / blocker |
|---|---|---|---|
| YYYY-MM-DD | 1 | Requirements, schema design | Chose Express + raw SQL for transparency |
