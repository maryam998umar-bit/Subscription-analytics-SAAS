export const metadata = { title: "SubMetrics" };
export default function Root({ children }) {
  return <html lang="en"><body style={{ fontFamily: "system-ui", margin: 0, background: "#f6f7fb", color: "#14213d" }}>{children}</body></html>;
}
