const express = require("express"), cors = require("cors"), jwt = require("jsonwebtoken"), bcrypt = require("bcryptjs");
const { pool } = require("./db");
const SECRET = process.env.JWT_SECRET;
if (!SECRET) throw new Error("JWT_SECRET is required");
const app = express();
app.use(cors({ origin: process.env.WEB_ORIGIN || "http://localhost:3000" }));
app.use(express.json({ limit: "50kb" }));

const wrap = fn => (req, res, next) => fn(req, res).catch(next);
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });
const audit = (db, req, action, entity, id, meta) =>
  db.query("INSERT INTO audit_log(user_id,role,action,entity,entity_id,meta) VALUES($1,$2,$3,$4,$5,$6)",
    [req.user?.sub ?? null, req.user?.role ?? null, action, entity, id ?? null, meta ?? {}]);

function auth(...roles) {
  return (req, res, next) => {
    const t = (req.headers.authorization || "").replace("Bearer ", "");
    try { req.user = jwt.verify(t, SECRET); } catch { return bad(res, "Unauthenticated", 401); }
    if (roles.length && !roles.includes(req.user.role)) {
      audit(pool, req, "DENIED " + req.method + " " + req.path).catch(() => {});
      return bad(res, "Forbidden for role " + req.user.role, 403);
    }
    next();
  };
}
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

app.get("/health", (_, res) => res.json({ ok: true }));

app.post("/auth/login", wrap(async (req, res) => {
  const { email, password } = req.body || {};
  if (typeof email !== "string" || typeof password !== "string") return bad(res, "email and password required");
  const u = (await pool.query("SELECT * FROM users WHERE email=$1", [email])).rows[0];
  if (!u || !(await bcrypt.compare(password, u.password_hash))) return bad(res, "Invalid credentials", 401);
  res.json({ token: jwt.sign({ sub: u.id, role: u.role }, SECRET, { expiresIn: "8h" }), role: u.role });
}));

app.get("/plans", auth(), wrap(async (_, res) => res.json((await pool.query("SELECT * FROM plans ORDER BY price_cents")).rows)));

app.get("/customers", auth(), wrap(async (_, res) => res.json((await pool.query(
  `SELECT c.*, p.name plan_name, p.included_units,
   COALESCE((SELECT sum(units) FROM usage_records u WHERE u.customer_id=c.id AND NOT u.billed),0)::int unbilled_units
   FROM customers c JOIN plans p ON p.id=c.plan_id ORDER BY c.id`)).rows)));

app.post("/customers", auth("admin"), wrap(async (req, res) => {
  const { name, email, plan_id } = req.body || {};
  if (typeof name !== "string" || name.trim().length < 2) return bad(res, "name must be at least 2 characters");
  if (typeof email !== "string" || !EMAIL.test(email)) return bad(res, "invalid email");
  if (!(await pool.query("SELECT 1 FROM plans WHERE id=$1", [plan_id])).rowCount) return bad(res, "unknown plan");
  try {
    const r = await pool.query("INSERT INTO customers(name,email,plan_id) VALUES($1,$2,$3) RETURNING *", [name.trim(), email.toLowerCase(), plan_id]);
    await audit(pool, req, "customer.create", "customer", r.rows[0].id, { plan_id });
    res.status(201).json(r.rows[0]);
  } catch (e) { if (e.code === "23505") return bad(res, "email already exists", 409); throw e; }
}));

app.patch("/customers/:id/plan", auth("admin"), wrap(async (req, res) => {
  const c = (await pool.query("SELECT * FROM customers WHERE id=$1", [+req.params.id])).rows[0];
  if (!c) return bad(res, "not found", 404);
  if (c.status === "canceled") return bad(res, "customer is canceled", 409);
  const p = (await pool.query("SELECT * FROM plans WHERE id=$1", [req.body?.plan_id])).rows[0];
  if (!p) return bad(res, "unknown plan");
  await pool.query("UPDATE customers SET plan_id=$1 WHERE id=$2", [p.id, c.id]);
  await audit(pool, req, "customer.plan_change", "customer", c.id, { from: c.plan_id, to: p.id });
  res.json({ ok: true });
}));

app.post("/customers/:id/cancel", auth("admin"), wrap(async (req, res) => {
  const r = await pool.query("UPDATE customers SET status='canceled', canceled_at=now() WHERE id=$1 AND status<>'canceled' RETURNING id", [+req.params.id]);
  if (!r.rowCount) return bad(res, "not found or already canceled", 404);
  await audit(pool, req, "customer.cancel", "customer", r.rows[0].id);
  res.json({ ok: true });
}));

app.post("/usage", auth("admin", "analyst"), wrap(async (req, res) => {
  const { customer_id, units } = req.body || {};
  if (!Number.isInteger(units) || units < 1 || units > 1e6) return bad(res, "units must be an integer 1..1000000");
  const c = (await pool.query("SELECT status FROM customers WHERE id=$1", [customer_id])).rows[0];
  if (!c) return bad(res, "customer not found", 404);
  if (c.status === "canceled") return bad(res, "customer is canceled", 409);
  await pool.query("INSERT INTO usage_records(customer_id,units) VALUES($1,$2)", [customer_id, units]);
  await audit(pool, req, "usage.record", "customer", customer_id, { units });
  res.status(201).json({ ok: true });
}));

// Simulated Stripe-like billing run. failRate (0..1) lets tests force outcomes.
app.post("/billing/run", auth("admin"), wrap(async (req, res) => {
  const failRate = req.body?.failRate ?? 0.15;
  if (typeof failRate !== "number" || failRate < 0 || failRate > 1) return bad(res, "failRate must be 0..1");
  const db = await pool.connect(); let paid = 0, failed = 0;
  try {
    await db.query("BEGIN");
    const cs = (await db.query(`SELECT c.id, p.price_cents, p.included_units, p.overage_cents_per_1000,
      COALESCE((SELECT sum(units) FROM usage_records u WHERE u.customer_id=c.id AND NOT u.billed),0)::int units
      FROM customers c JOIN plans p ON p.id=c.plan_id WHERE c.status='active' FOR UPDATE OF c`)).rows;
    for (const c of cs) {
      const amount = c.price_cents + Math.ceil(Math.max(0, c.units - c.included_units) / 1000) * c.overage_cents_per_1000;
      if (Math.random() < failRate) {
        failed++; await db.query("UPDATE customers SET status='past_due' WHERE id=$1", [c.id]);
        await db.query("INSERT INTO billing_events(customer_id,type,amount_cents,status) VALUES($1,'invoice.payment_failed',$2,'failed')", [c.id, amount]);
      } else {
        paid++; await db.query("UPDATE usage_records SET billed=true WHERE customer_id=$1", [c.id]);
        await db.query("INSERT INTO billing_events(customer_id,type,amount_cents,status) VALUES($1,'invoice.paid',$2,'paid')", [c.id, amount]);
      }
    }
    await audit(db, req, "billing.run", "billing", null, { paid, failed });
    await db.query("COMMIT");
  } catch (e) { await db.query("ROLLBACK"); throw e; } finally { db.release(); }
  res.json({ paid, failed });
}));

app.post("/billing/retry/:id", auth("admin"), wrap(async (req, res) => {
  const r = await pool.query("UPDATE customers SET status='active' WHERE id=$1 AND status='past_due' RETURNING plan_id", [+req.params.id]);
  if (!r.rowCount) return bad(res, "customer is not past_due", 404);
  await pool.query(`INSERT INTO billing_events(customer_id,type,amount_cents,status)
    SELECT $1,'invoice.paid',price_cents,'paid' FROM plans WHERE id=$2`, [+req.params.id, r.rows[0].plan_id]);
  await audit(pool, req, "billing.retry", "customer", +req.params.id);
  res.json({ ok: true });
}));

app.get("/billing/events", auth(), wrap(async (_, res) => res.json((await pool.query(
  "SELECT b.*, c.name customer FROM billing_events b JOIN customers c ON c.id=b.customer_id ORDER BY b.id DESC LIMIT 100")).rows)));

app.get("/analytics/summary", auth(), wrap(async (_, res) => {
  const q = async s => (await pool.query(s)).rows;
  const [t] = await q(`SELECT
    COALESCE(sum(p.price_cents) FILTER (WHERE c.status<>'canceled'),0)::int mrr_cents,
    count(*) FILTER (WHERE c.status='active')::int active,
    count(*) FILTER (WHERE c.status='past_due')::int past_due,
    count(*) FILTER (WHERE c.status='canceled')::int canceled,
    count(*)::int total FROM customers c JOIN plans p ON p.id=c.plan_id`);
  const byPlan = await q(`SELECT p.id, p.name, count(c.id)::int customers, COALESCE(sum(p.price_cents),0)::int mrr_cents
    FROM plans p LEFT JOIN customers c ON c.plan_id=p.id AND c.status<>'canceled' GROUP BY p.id ORDER BY p.price_cents`);
  const rev = await q(`SELECT to_char(date_trunc('month',created_at),'YYYY-MM') month, sum(amount_cents)::int revenue_cents
    FROM billing_events WHERE status='paid' GROUP BY 1 ORDER BY 1 DESC LIMIT 6`);
  const live = t.active + t.past_due;
  res.json({ ...t, arpu_cents: live ? Math.round(t.mrr_cents / live) : 0,
    churn_rate: t.total ? +(t.canceled / t.total).toFixed(4) : 0, by_plan: byPlan, revenue_by_month: rev.reverse() });
}));

app.get("/audit", auth("admin", "analyst"), wrap(async (_, res) =>
  res.json((await pool.query("SELECT * FROM audit_log ORDER BY id DESC LIMIT 200")).rows)));

app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: "Internal error" }); });
module.exports = app;
