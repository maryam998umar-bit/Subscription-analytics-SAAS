"use client";
import { useState, useCallback } from "react";
const API = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";
const $ = c => "$" + (c / 100).toFixed(2);
const card = { background: "#fff", border: "1px solid #e3e7f0", borderRadius: 12, padding: 14, marginBottom: 14 };

export default function Page() {
  const [tok, setTok] = useState(null), [role, setRole] = useState(""), [msg, setMsg] = useState("");
  const [sum, setSum] = useState(null), [cust, setCust] = useState([]), [ev, setEv] = useState([]);
  const [f, setF] = useState({ email: "admin@demo.test", password: "Passw0rd!demo" });

  const api = useCallback(async (method, path, body, t = tok) => {
    const r = await fetch(API + path, { method, headers: { "content-type": "application/json", ...(t && { authorization: "Bearer " + t }) }, body: body && JSON.stringify(body) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || r.statusText);
    return j;
  }, [tok]);
  const load = useCallback(async t => {
    setSum(await api("GET", "/analytics/summary", null, t));
    setCust(await api("GET", "/customers", null, t));
    setEv(await api("GET", "/billing/events", null, t));
  }, [api]);
  const act = async (fn, ok) => { try { await fn(); setMsg(ok); await load(); } catch (e) { setMsg("Error: " + e.message); } };

  async function login(e) {
    e.preventDefault();
    try { const r = await api("POST", "/auth/login", f, null); setTok(r.token); setRole(r.role); setMsg(""); await load(r.token); }
    catch (er) { setMsg("Error: " + er.message); }
  }
  if (!tok) return (
    <form onSubmit={login} style={{ ...card, maxWidth: 340, margin: "60px auto" }}>
      <h2>SubMetrics login</h2>
      <input style={{ width: "100%", marginBottom: 8 }} value={f.email} onChange={e => setF({ ...f, email: e.target.value })} />
      <input style={{ width: "100%", marginBottom: 8 }} type="password" value={f.password} onChange={e => setF({ ...f, password: e.target.value })} />
      <button>Sign in</button><p>{msg}</p>
      <small>Demo: admin / analyst / viewer @demo.test</small>
    </form>);
  return (
    <main style={{ maxWidth: 960, margin: "0 auto", padding: 16 }}>
      <h1>SubMetrics <small style={{ fontSize: 14 }}>({role})</small></h1>
      <p style={{ color: msg.startsWith("Error") ? "#dc2626" : "#16a34a" }}>{msg}</p>
      {sum && <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))", gap: 10 }}>
        {[["MRR", $(sum.mrr_cents)], ["Active", sum.active], ["ARPU", $(sum.arpu_cents)], ["Churn", (sum.churn_rate * 100).toFixed(1) + "%"], ["Past due", sum.past_due]]
          .map(([k, v]) => <div key={k} style={card}><small>{k}</small><div style={{ fontSize: 22, fontWeight: 700 }}>{v}</div></div>)}</div>}
      {sum && <div style={card}><b>Revenue by plan (MRR)</b>{sum.by_plan.map(p =>
        <div key={p.id}>{p.name}: {p.customers} customers, {$(p.mrr_cents)}
          <div style={{ height: 8, borderRadius: 4, background: "#2563eb", width: (sum.mrr_cents ? p.mrr_cents / sum.mrr_cents * 100 : 0) + "%" }} /></div>)}</div>}
      <div style={card}>
        <button disabled={role !== "admin"} onClick={() => act(() => api("POST", "/billing/run", {}), "Billing cycle complete")}>Run billing cycle</button>
        <div style={{ overflowX: "auto" }}><table style={{ width: "100%", minWidth: 560 }}><thead><tr><th>Customer</th><th>Plan</th><th>Status</th><th>Unbilled units</th><th /></tr></thead>
          <tbody>{cust.map(c => <tr key={c.id}><td>{c.name}</td><td>{c.plan_name}</td><td>{c.status}</td><td>{c.unbilled_units}/{c.included_units}</td>
            <td>{c.status === "past_due" && <button disabled={role !== "admin"} onClick={() => act(() => api("POST", "/billing/retry/" + c.id, {}), "Retried")}>Retry</button>}
              <button disabled={role === "viewer" || c.status === "canceled"} onClick={() => act(() => api("POST", "/usage", { customer_id: c.id, units: 250 }), "Recorded 250 units")}>+250 usage</button></td></tr>)}</tbody></table></div>
      </div>
      <div style={card}><b>Recent billing events</b>{ev.slice(0, 8).map(e => <div key={e.id}>{e.customer} · {e.type} · {$(e.amount_cents)} · {e.status}</div>)}</div>
    </main>);
}
