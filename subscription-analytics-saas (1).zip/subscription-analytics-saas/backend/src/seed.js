const bcrypt = require("bcryptjs"), { pool } = require("./db");
(async () => {
  const h = await bcrypt.hash("Passw0rd!demo", 10);
  for (const r of ["admin", "analyst", "viewer"])
    await pool.query("INSERT INTO users(email,password_hash,role) VALUES($1,$2,$3) ON CONFLICT DO NOTHING", [`${r}@demo.test`, h, r]);
  const n = (await pool.query("SELECT count(*) FROM customers")).rows[0].count;
  if (+n === 0) for (const [i, nm] of ["Acme Corp", "Globex", "Initech", "Hooli", "Umbrella", "Wonka"].entries())
    await pool.query("INSERT INTO customers(name,email,plan_id) VALUES($1,$2,$3)",
      [nm, nm.toLowerCase().replace(/\W/g, "") + "@example.com", ["starter", "growth", "scale"][i % 3]]);
  console.log("seeded"); await pool.end();
})().catch(e => { console.error(e); process.exit(1); });
