# SubMetrics — Subscription Analytics SaaS MVP

Capstone for Arrowstack Full Stack Development internship (Project 3).
Stack: Next.js 14 · Node.js/Express · PostgreSQL 16 · JWT · Docker · simulated Stripe-like billing.

## Run (Docker)
```bash
docker compose up --build
# web: http://localhost:3000   api: http://localhost:4000/health
```
Demo logins (password `Passw0rd!demo`): `admin@demo.test`, `analyst@demo.test`, `viewer@demo.test`.

## Run tests
```bash
docker compose up -d db api
docker compose exec api npm test      # integration tests against the live DB
```

## Stakeholder, decision, metric
- **Stakeholder:** SaaS founder / finance lead. **Decision:** which plans to push and which at-risk accounts to chase.
- **Success metrics:** MRR, ARPU, churn rate, past-due count visible in < 1 s; every state change audited.

## Roles
| Role | Can do |
|---|---|
| admin | everything: customers, plan changes, cancel, usage, billing, audit |
| analyst | record usage, read analytics, read audit log |
| viewer | read analytics, customers, billing events |

## Architecture
`web (Next.js)` → REST/JWT → `api (Express)` → `PostgreSQL`. Schema + seed plans in `backend/migrations/001_init.sql`; applied by `src/migrate.js` (tracked in `schema_migrations`).

## Requirement → evidence map
| Requirement | Where |
|---|---|
| Role-based access | `auth(...roles)` in `src/app.js`; tests "RBAC" |
| REST API | `src/app.js` (14 endpoints) |
| Relational DB + migrations | `migrations/`, `src/migrate.js` |
| Validation & error handling | per-route checks, 400/401/403/404/409 codes, central error handler |
| Audit-friendly records | `audit_log` table, also logs denied attempts |
| Deployment-ready config | `docker-compose.yml`, Dockerfiles, env-based secrets |
| Simulated billing | `POST /billing/run` (configurable `failRate`), retry endpoint |

## Edge cases handled
Duplicate email (409) · canceled customer cannot change plan or log usage · invalid/negative usage · failed payment → `past_due` + retry · billing runs in one transaction with row locks.

## Known limitations
No refresh tokens or password reset · MRR history derived from paid invoices only · billing is simulated (no real Stripe) · no rate limiting · single currency · frontend is minimal.

## Next steps (production readiness)
Real Stripe webhooks with idempotency keys · rate limiting + helmet · refresh-token rotation · pagination · Prometheus metrics · CI pipeline · read replica or materialized views for analytics at 10× scale.

## Work log
Keep dated entries in `docs/worklog.md` (template included).
